import torch

from diffubrain.models import DiffuBrain
from diffubrain.training.calibration import TemperatureScaler


def test_2d_forward():
    model = DiffuBrain(feature_channels=16, diffusion_steps=8)
    output = model(torch.randn(2, 1, 32, 32), "brisc")
    assert output["seg_logits"].shape[:2] == (2, 1)
    assert output["cls_logits"].shape == (2, 4)


def test_3d_forward():
    model = DiffuBrain(feature_channels=16, diffusion_steps=8)
    output = model(torch.randn(1, 4, 16, 16, 16), "brats")
    assert output["seg_logits"].shape[:2] == (1, 1)
    assert output["cls_logits"].shape == (1, 4)


def test_temperature_scaling():
    scaler = TemperatureScaler().fit(torch.randn(12, 4).numpy(), torch.randint(0, 4, (12,)).numpy())
    assert scaler.temperature > 0
