from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
import torch.nn.functional as F


def read_manifest(path: str | Path) -> list[dict[str, Any]]:
    records = []
    with open(path, "r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if line.strip():
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Invalid JSONL at line {line_number}") from exc
    return records


def _load_array(path: str | Path) -> np.ndarray:
    path = str(path)
    if path.endswith(".npy"):
        return np.load(path)
    if path.endswith((".nii", ".nii.gz")):
        try:
            import nibabel as nib
        except ImportError as exc:
            raise ImportError("Install the medical extra to read NIfTI files") from exc
        return np.asarray(nib.load(path).get_fdata())
    raise ValueError(f"Unsupported array format: {path}")


def _to_image_tensor(array: np.ndarray, is_volume: bool) -> torch.Tensor:
    x = torch.as_tensor(array, dtype=torch.float32)
    if is_volume:
        if x.ndim == 3:
            x = x.unsqueeze(0)
        elif x.ndim != 4:
            raise ValueError(f"Expected D,H,W or C,D,H,W, got {tuple(x.shape)}")
    else:
        if x.ndim == 2:
            x = x.unsqueeze(0)
        elif x.ndim != 3:
            raise ValueError(f"Expected H,W or C,H,W, got {tuple(x.shape)}")
    x = (x - x.mean()) / x.std().clamp_min(1e-6)
    return x


class ManifestDataset(Dataset):
    def __init__(self, records: list[dict[str, Any]], is_volume: bool, training: bool = False):
        self.records = records
        self.is_volume = is_volume
        self.training = training

    def __len__(self) -> int:
        return len(self.records)

    def __getitem__(self, index: int) -> dict[str, Any]:
        record = self.records[index]
        image = _to_image_tensor(_load_array(record["image"]), self.is_volume)
        if self.training and torch.rand(()) < 0.5:
            image = image.flip(-1)
        if self.training and torch.rand(()) < 0.2:
            image = image + 0.01 * torch.randn_like(image)
        result: dict[str, Any] = {"image": image, "id": record.get("id", str(index)), "dataset": record.get("dataset")}
        if record.get("mask"):
            mask = torch.as_tensor(_load_array(record["mask"]), dtype=torch.float32)
            result["mask"] = (mask > 0).float().unsqueeze(0) if mask.ndim in (2, 3) else mask
        else:
            result["mask"] = None
        result["label"] = torch.tensor(int(record["label"]), dtype=torch.long) if record.get("label") is not None else None
        return result


def _collate(batch: list[dict[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {"image": torch.stack([x["image"] for x in batch]), "id": [x["id"] for x in batch], "dataset": [x["dataset"] for x in batch]}
    masks = [x["mask"] for x in batch]
    labels = [x["label"] for x in batch]
    result["mask"] = torch.stack(masks) if all(x is not None for x in masks) else None
    result["label"] = torch.stack(labels) if all(x is not None for x in labels) else None
    return result


def build_loaders(records: list[dict[str, Any]], batch_size_2d: int, batch_size_3d: int, workers: int = 0) -> dict[str, DataLoader]:
    loaders = {}
    for split in ("train", "val", "test"):
        for dataset_name, is_volume, batch_size in (("brisc", False, batch_size_2d), ("brats", True, batch_size_3d)):
            subset = [r for r in records if r.get("split") == split and r.get("dataset", "").lower().startswith(dataset_name)]
            if subset:
                ds = ManifestDataset(subset, is_volume=is_volume, training=split == "train")
                loaders[f"{dataset_name}_{split}"] = DataLoader(ds, batch_size=batch_size, shuffle=split == "train", num_workers=workers, collate_fn=_collate)
    return loaders
