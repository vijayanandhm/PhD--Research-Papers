from __future__ import annotations

import torch
from torch import nn

from .blocks import ConvNormAct, ResidualStage


class Encoder2D(nn.Module):
    def __init__(self, in_channels: int = 1, feature_channels: int = 128):
        super().__init__()
        self.stem = ConvNormAct(2, in_channels, 32)
        self.stage1 = ResidualStage(2, 32, 64)
        self.stage2 = ResidualStage(2, 64, feature_channels)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, list[torch.Tensor]]:
        skips = [self.stem(x)]
        x = self.stage1(skips[-1])
        skips.append(x)
        return self.stage2(x), skips


class Encoder3D(nn.Module):
    def __init__(self, in_channels: int = 4, feature_channels: int = 128):
        super().__init__()
        self.stem = ConvNormAct(3, in_channels, 32)
        self.stage1 = ResidualStage(3, 32, 64)
        self.stage2 = ResidualStage(3, 64, feature_channels)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, list[torch.Tensor]]:
        skips = [self.stem(x)]
        x = self.stage1(skips[-1])
        skips.append(x)
        return self.stage2(x), skips
