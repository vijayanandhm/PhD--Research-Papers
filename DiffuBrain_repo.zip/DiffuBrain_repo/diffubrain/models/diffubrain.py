from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F

from .diffusion import DiffusionRefiner
from .encoders import Encoder2D, Encoder3D
from .heads import ClassificationHead, SegmentationHead


class DiffuBrain(nn.Module):
    def __init__(self, feature_channels: int = 128, num_classes: int = 4, diffusion_steps: int = 1000, gamma: float = 0.5, conditioning_dropout: float = 0.2):
        super().__init__()
        self.encoder2d = Encoder2D(1, feature_channels)
        self.encoder3d = Encoder3D(4, feature_channels)
        self.refiner = DiffusionRefiner(feature_channels, diffusion_steps, dropout=conditioning_dropout, gamma=gamma)
        self.segmentation = SegmentationHead(feature_channels)
        self.classification = ClassificationHead(feature_channels, num_classes)

    def forward(self, image: torch.Tensor, dataset: str, return_loss: bool = True) -> dict[str, torch.Tensor | None]:
        is_2d = image.ndim == 4 or dataset.lower() == "brisc"
        if is_2d:
            features, skips = self.encoder2d(image)
        else:
            features, skips = self.encoder3d(image)
        refined, diffusion_loss = self.refiner(features, image)
        seg_logits = self.segmentation(refined)
        cls_logits = self.classification(refined)
        return {"features": refined, "seg_logits": seg_logits, "cls_logits": cls_logits, "diffusion_loss": diffusion_loss if return_loss else None, "skips": skips}
