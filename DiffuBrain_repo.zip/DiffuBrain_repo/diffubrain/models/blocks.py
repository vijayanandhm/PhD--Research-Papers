from __future__ import annotations

import torch
from torch import nn


class ConvNormAct(nn.Module):
    def __init__(self, dim: int, cin: int, cout: int, stride: int = 1):
        super().__init__()
        conv = nn.Conv2d if dim == 2 else nn.Conv3d
        norm = nn.BatchNorm2d if dim == 2 else nn.BatchNorm3d
        self.block = nn.Sequential(conv(cin, cout, 3, stride, 1, bias=False), norm(cout), nn.SiLU())

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class ResidualStage(nn.Module):
    def __init__(self, dim: int, cin: int, cout: int):
        super().__init__()
        self.main = nn.Sequential(ConvNormAct(dim, cin, cout, 2), ConvNormAct(dim, cout, cout))
        conv = nn.Conv2d if dim == 2 else nn.Conv3d
        self.skip = conv(cin, cout, 1, 2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.main(x) + self.skip(x)
