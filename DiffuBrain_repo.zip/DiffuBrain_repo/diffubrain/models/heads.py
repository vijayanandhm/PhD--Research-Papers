from __future__ import annotations

import torch
from torch import nn
import torch.nn.functional as F


class SegmentationHead(nn.Module):
    def __init__(self, channels: int = 128):
        super().__init__()
        self.proj2d = nn.Conv2d(channels, 1, 1)
        self.proj3d = nn.Conv3d(channels, 1, 1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.proj3d(x) if x.ndim == 5 else self.proj2d(x)


class ClassificationHead(nn.Module):
    def __init__(self, channels: int = 128, classes: int = 4):
        super().__init__()
        self.proj = nn.Linear(channels, classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dims = tuple(range(2, x.ndim))
        return self.proj(x.mean(dim=dims))
