from __future__ import annotations

import math

import torch
from torch import nn
import torch.nn.functional as F


def edge_weight(image: torch.Tensor, gamma: float = 0.5) -> torch.Tensor:
    spatial_dims = range(2, image.ndim)
    grad = torch.zeros_like(image)
    for dim in spatial_dims:
        shifted = torch.roll(image, shifts=1, dims=dim)
        index = [slice(None)] * image.ndim
        index[dim] = 0
        shifted[tuple(index)] = image[tuple(index)]
        grad = grad + (image - shifted).abs()
    scale = grad.mean(dim=1, keepdim=True)
    return 1.0 + gamma * scale


class TimeEmbedding(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim
        self.proj = nn.Sequential(nn.Linear(dim, dim * 2), nn.SiLU(), nn.Linear(dim * 2, dim))

    def forward(self, t: torch.Tensor) -> torch.Tensor:
        half = self.dim // 2
        frequencies = torch.exp(-math.log(10000) * torch.arange(half, device=t.device) / max(half - 1, 1))
        values = t.float()[:, None] * frequencies[None]
        emb = torch.cat((values.sin(), values.cos()), dim=1)
        return self.proj(emb)


class ConditionalDenoiser(nn.Module):
    def __init__(self, channels: int = 128, condition_channels: int = 129):
        super().__init__()
        self.time = TimeEmbedding(channels)
        self.in_proj = nn.Conv1d(condition_channels + channels, channels, 1)
        self.time_proj = nn.Linear(channels, channels)
        self.body = nn.Sequential(nn.Conv1d(channels, channels, 3, padding=1), nn.GroupNorm(8, channels), nn.SiLU(), nn.Conv1d(channels, channels, 3, padding=1))
        self.out = nn.Conv1d(channels, channels, 1)

    def forward(self, noisy: torch.Tensor, t: torch.Tensor, condition: torch.Tensor) -> torch.Tensor:
        if noisy.ndim == 5:
            shape = noisy.shape
            noisy = noisy.flatten(2)
            condition = condition.flatten(2)
            x = torch.cat((noisy, condition), dim=1)
            x = self.in_proj(x) + self.time_proj(self.time(t))[:, :, None]
            x = self.out(self.body(x))
            return x.reshape(shape)
        shape = noisy.shape
        x = self.in_proj(torch.cat((noisy.flatten(2), condition.flatten(2)), dim=1))
        x = x + self.time_proj(self.time(t))[:, :, None]
        x = self.out(self.body(x))
        return x.reshape(shape)


class DiffusionRefiner(nn.Module):
    def __init__(self, channels: int = 128, steps: int = 1000, beta_start: float = 1e-4, beta_end: float = 0.02, dropout: float = 0.2, gamma: float = 0.5):
        super().__init__()
        self.steps = steps
        self.gamma = gamma
        self.dropout = dropout
        betas = torch.linspace(beta_start, beta_end, steps)
        self.register_buffer("betas", betas)
        self.register_buffer("alphas_cumprod", torch.cumprod(1.0 - betas, dim=0))
        self.denoiser = ConditionalDenoiser(channels, channels + 1)

    def q_sample(self, clean: torch.Tensor, t: torch.Tensor, noise: torch.Tensor) -> torch.Tensor:
        alpha = self.alphas_cumprod[t].view(-1, *([1] * (clean.ndim - 1)))
        return alpha.sqrt() * clean + (1 - alpha).sqrt() * noise

    def forward(self, clean: torch.Tensor, image: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        t = torch.randint(0, self.steps, (clean.shape[0],), device=clean.device)
        noise = torch.randn_like(clean)
        edge = edge_weight(image, self.gamma)
        edge = F.interpolate(edge, size=clean.shape[2:], mode="nearest")
        condition = torch.cat((clean.detach(), edge), dim=1)
        if self.training:
            condition = F.dropout(condition, p=self.dropout, training=True)
        predicted = self.denoiser(self.q_sample(clean, t, noise), t, condition)
        loss = ((predicted - noise).pow(2) * edge).mean()
        return clean, loss
