from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class Config:
    seed: int = 42
    device: str = "auto"
    num_workers: int = 0
    epochs: int = 200
    batch_size_2d: int = 8
    batch_size_3d: int = 2
    learning_rate: float = 1e-4
    weight_decay: float = 1e-2
    num_classes: int = 4
    feature_channels: int = 128
    image_size_2d: tuple[int, int] = (256, 256)
    volume_size_3d: tuple[int, int, int] = (128, 128, 128)
    diffusion_steps: int = 1000
    sampling_steps: int = 50
    beta_start: float = 1e-4
    beta_end: float = 0.02
    edge_gamma: float = 0.5
    conditioning_dropout: float = 0.2
    normal_reference_weight: float = 0.1
    lambda_diffusion: float = 1.0
    lambda_segmentation: float = 1.0
    lambda_classification: float = 1.0
    lambda_boundary: float = 0.5
    amp: bool = True
    grad_clip: float = 1.0
    save_every: int = 10
    extra: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_yaml(cls, path: str | Path) -> "Config":
        with open(path, "r", encoding="utf-8") as handle:
            values = yaml.safe_load(handle) or {}
        known = {k: v for k, v in values.items() if k in cls.__dataclass_fields__}
        for key in ("image_size_2d", "volume_size_3d"):
            if key in known:
                known[key] = tuple(known[key])
        cfg = cls(**known)
        cfg.extra = {k: v for k, v in values.items() if k not in cls.__dataclass_fields__}
        return cfg

    def to_dict(self) -> dict[str, Any]:
        result = {k: getattr(self, k) for k in self.__dataclass_fields__ if k != "extra"}
        result["image_size_2d"] = list(self.image_size_2d)
        result["volume_size_3d"] = list(self.volume_size_3d)
        result.update(self.extra)
        return result
