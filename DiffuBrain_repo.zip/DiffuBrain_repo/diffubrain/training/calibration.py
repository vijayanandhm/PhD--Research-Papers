from __future__ import annotations

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import softmax


class TemperatureScaler:
    def __init__(self, temperature: float = 1.0):
        self.temperature = float(temperature)

    def fit(self, logits: np.ndarray, labels: np.ndarray) -> "TemperatureScaler":
        logits = np.asarray(logits, dtype=np.float64)
        labels = np.asarray(labels, dtype=np.int64)

        def objective(log_temperature: float) -> float:
            probs = softmax(logits / np.exp(log_temperature), axis=1)
            return float(-np.log(np.clip(probs[np.arange(len(labels)), labels], 1e-12, 1)).mean())

        result = minimize_scalar(objective, bounds=(-3, 3), method="bounded")
        self.temperature = float(np.exp(result.x))
        return self

    def transform(self, logits: np.ndarray) -> np.ndarray:
        return softmax(np.asarray(logits) / self.temperature, axis=1)


def expected_calibration_error(probabilities: np.ndarray, labels: np.ndarray, bins: int = 10) -> float:
    probabilities = np.asarray(probabilities)
    labels = np.asarray(labels)
    confidence = probabilities.max(axis=1)
    prediction = probabilities.argmax(axis=1)
    edges = np.linspace(0, 1, bins + 1)
    error = 0.0
    for low, high in zip(edges[:-1], edges[1:]):
        selected = (confidence > low) & (confidence <= high)
        if selected.any():
            error += selected.mean() * abs((prediction[selected] == labels[selected]).mean() - confidence[selected].mean())
    return float(error)
