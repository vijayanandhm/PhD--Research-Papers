from __future__ import annotations

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix


def segmentation_metrics(probability: np.ndarray, target: np.ndarray, threshold: float = 0.5) -> dict[str, float]:
    pred = probability >= threshold
    target = target.astype(bool)
    intersection = np.logical_and(pred, target).sum()
    union = np.logical_or(pred, target).sum()
    dice = (2 * intersection) / (pred.sum() + target.sum() + 1e-8)
    iou = intersection / (union + 1e-8)
    return {"dice": float(dice), "iou": float(iou)}


def multiclass_metrics(prediction: np.ndarray, target: np.ndarray) -> dict[str, object]:
    return {"accuracy": float(accuracy_score(target, prediction)), "weighted_f1": float(f1_score(target, prediction, average="weighted")), "confusion_matrix": confusion_matrix(target, prediction).tolist()}


def binary_metrics(probability: np.ndarray, target: np.ndarray) -> dict[str, float]:
    return segmentation_metrics(probability, target)
