from __future__ import annotations

import torch
from torch.nn import functional as F


def dice_loss(logits: torch.Tensor, target: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    probs = logits.sigmoid()
    dims = tuple(range(1, probs.ndim))
    score = (2 * (probs * target).sum(dims) + eps) / (probs.sum(dims) + target.sum(dims) + eps)
    return 1 - score.mean()


def boundary_loss(logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    probs = logits.sigmoid()
    if probs.ndim == 4:
        dx_p, dy_p = probs[..., 1:, :] - probs[..., :-1, :], probs[..., :, 1:] - probs[..., :, :-1]
        dx_t, dy_t = target[..., 1:, :] - target[..., :-1, :], target[..., :, 1:] - target[..., :, :-1]
    else:
        dx_p, dy_p = probs[..., 1:, :, :] - probs[..., :-1, :, :], probs[..., :, 1:, :] - probs[..., :, :-1, :]
        dx_t, dy_t = target[..., 1:, :, :] - target[..., :-1, :, :], target[..., :, 1:, :] - target[..., :, :-1, :]
    return F.l1_loss(dx_p, dx_t) + F.l1_loss(dy_p, dy_t)


def multitask_loss(output: dict, mask: torch.Tensor | None, label: torch.Tensor | None, lambda_diffusion: float = 1.0, lambda_segmentation: float = 1.0, lambda_classification: float = 1.0, lambda_boundary: float = 0.5) -> dict[str, torch.Tensor]:
    device = output["seg_logits"].device
    total = output["diffusion_loss"] * lambda_diffusion
    terms = {"diffusion": output["diffusion_loss"]}
    if mask is not None:
        seg = dice_loss(output["seg_logits"], mask) + F.binary_cross_entropy_with_logits(output["seg_logits"], mask)
        bnd = boundary_loss(output["seg_logits"], mask)
        total = total + lambda_segmentation * seg + lambda_boundary * bnd
        terms.update(segmentation=seg, boundary=bnd)
    else:
        terms.update(segmentation=torch.zeros((), device=device), boundary=torch.zeros((), device=device))
    if label is not None:
        cls = F.cross_entropy(output["cls_logits"], label)
        total = total + lambda_classification * cls
        terms["classification"] = cls
    else:
        terms["classification"] = torch.zeros((), device=device)
    terms["total"] = total
    return terms
