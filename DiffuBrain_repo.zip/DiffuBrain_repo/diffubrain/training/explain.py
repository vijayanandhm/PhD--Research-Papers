from __future__ import annotations

import torch


class GradCAM:
    def __init__(self, model: torch.nn.Module, layer: torch.nn.Module):
        self.model = model
        self.activations = None
        self.gradients = None
        layer.register_forward_hook(self._forward_hook)
        layer.register_full_backward_hook(self._backward_hook)

    def _forward_hook(self, _module, _inputs, output):
        self.activations = output

    def _backward_hook(self, _module, _grad_input, grad_output):
        self.gradients = grad_output[0]

    def __call__(self, image: torch.Tensor, dataset: str, class_index: int | None = None) -> torch.Tensor:
        self.model.zero_grad(set_to_none=True)
        output = self.model(image, dataset, return_loss=False)
        scores = output["cls_logits"]
        index = scores.argmax(1) if class_index is None else torch.full((scores.shape[0],), class_index, device=scores.device, dtype=torch.long)
        scores.gather(1, index[:, None]).sum().backward()
        weights = self.gradients.mean(dim=tuple(range(2, self.gradients.ndim)), keepdim=True)
        cam = (weights * self.activations).sum(1, keepdim=True).relu()
        return cam / cam.amax(dim=tuple(range(2, cam.ndim)), keepdim=True).clamp_min(1e-6)
