# Reproducibility artifacts

This directory is the canonical location for run-specific research artifacts:

```text
artifacts/
  splits/        Fixed split indices for every dataset and task
  checkpoints/   Best checkpoints for seeds 42, 123, 456, 789, and 1011
  predictions/   Per-case test predictions for each seed and dataset
  metrics/       Per-case metrics and aggregate summaries
  calibration/  Validation-fitted temperature parameters and calibration reports
```

The training and evaluation scripts write these outputs under the configured run directory. Keep large model and prediction files in the repository's release storage or DOI archive and record their checksums here before publication.
