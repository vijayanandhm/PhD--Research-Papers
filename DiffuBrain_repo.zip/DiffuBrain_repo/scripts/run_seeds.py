from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import yaml


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[42, 123, 456, 789, 1011])
    args = parser.parse_args()
    base = yaml.safe_load(Path(args.config).read_text(encoding="utf-8"))
    for seed in args.seeds:
        run_config = Path(args.output) / f"config-{seed}.yaml"
        run_config.parent.mkdir(parents=True, exist_ok=True)
        values = dict(base)
        values["seed"] = seed
        run_config.write_text(yaml.safe_dump(values, sort_keys=False), encoding="utf-8")
        subprocess.run([sys.executable, "scripts/train.py", "--config", str(run_config), "--manifest", args.manifest, "--output", args.output], check=True)


if __name__ == "__main__":
    main()
