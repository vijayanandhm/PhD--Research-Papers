from __future__ import annotations

import argparse
from pathlib import Path

import torch
import yaml
from tqdm import tqdm

from diffubrain.config import Config
from diffubrain.data import build_loaders, read_manifest
from diffubrain.models import DiffuBrain
from diffubrain.training.losses import multitask_loss
from diffubrain.utils import resolve_device, save_json, seed_everything


def train_one_epoch(model, loaders, optimizer, scaler, cfg, device):
    model.train()
    iterator = zip(loaders.get("brisc_train", []), loaders.get("brats_train", []))
    total = 0.0
    steps = 0
    for batch_2d, batch_3d in tqdm(iterator, leave=False):
        optimizer.zero_grad(set_to_none=True)
        losses = []
        for batch, dataset in ((batch_2d, "brisc"), (batch_3d, "brats")):
            image = batch["image"].to(device)
            mask = batch["mask"].to(device) if batch["mask"] is not None else None
            label = batch["label"].to(device) if batch["label"] is not None else None
            with torch.autocast(device_type=device.type, enabled=cfg.amp and device.type == "cuda"):
                output = model(image, dataset)
                terms = multitask_loss(output, mask, label, cfg.lambda_diffusion, cfg.lambda_segmentation, cfg.lambda_classification, cfg.lambda_boundary)
            losses.append(terms["total"])
        loss = sum(losses) / len(losses)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
        scaler.step(optimizer)
        scaler.update()
        total += float(loss.detach())
        steps += 1
    return total / max(steps, 1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()
    cfg = Config.from_yaml(args.config)
    device = resolve_device(args.device or cfg.device)
    seed_everything(cfg.seed)
    out = Path(args.output) / f"seed-{cfg.seed}"
    out.mkdir(parents=True, exist_ok=True)
    save_json(out / "config.json", cfg.to_dict())
    records = read_manifest(args.manifest)
    loaders = build_loaders(records, cfg.batch_size_2d, cfg.batch_size_3d, cfg.num_workers)
    model = DiffuBrain(cfg.feature_channels, cfg.num_classes, cfg.diffusion_steps, cfg.edge_gamma, cfg.conditioning_dropout).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate, weight_decay=cfg.weight_decay)
    scaler = torch.cuda.amp.GradScaler(enabled=cfg.amp and device.type == "cuda")
    best = float("inf")
    history = []
    for epoch in range(1, cfg.epochs + 1):
        loss = train_one_epoch(model, loaders, optimizer, scaler, cfg, device)
        history.append({"epoch": epoch, "loss": loss})
        if loss < best:
            best = loss
            torch.save({"model": model.state_dict(), "config": cfg.to_dict(), "epoch": epoch}, out / "best.pt")
        if epoch % cfg.save_every == 0:
            torch.save({"model": model.state_dict(), "config": cfg.to_dict(), "epoch": epoch}, out / f"epoch-{epoch}.pt")
    save_json(out / "history.json", history)


if __name__ == "__main__":
    main()
