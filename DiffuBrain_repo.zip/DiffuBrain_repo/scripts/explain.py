from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch

from diffubrain.config import Config
from diffubrain.data import ManifestDataset, read_manifest
from diffubrain.models import DiffuBrain
from diffubrain.training.explain import GradCAM
from diffubrain.utils import resolve_device


def main(args):
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    cfg = Config(**{k: v for k, v in checkpoint["config"].items() if k in Config.__dataclass_fields__})
    device = resolve_device(args.device)
    model = DiffuBrain(cfg.feature_channels, cfg.num_classes, cfg.diffusion_steps, cfg.edge_gamma, cfg.conditioning_dropout).to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()
    cam = GradCAM(model, model.refiner.denoiser.body[-1])
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    for record in read_manifest(args.manifest):
        if record.get("split") != args.split:
            continue
        is_2d = record.get("dataset", "").lower().startswith("brisc")
        sample = ManifestDataset([record], is_volume=not is_2d)[0]
        image = sample["image"].unsqueeze(0).to(device)
        explanation = cam(image, "brisc" if is_2d else "brats").detach().cpu().numpy()[0]
        np.save(output_dir / f"{sample['id']}.npy", explanation)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument("--device", default="cpu")
    main(parser.parse_args())
