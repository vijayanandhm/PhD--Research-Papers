from __future__ import annotations

import argparse
import json

import numpy as np
import torch

from diffubrain.config import Config
from diffubrain.data import ManifestDataset, read_manifest
from diffubrain.models import DiffuBrain
from diffubrain.training.calibration import TemperatureScaler, expected_calibration_error
from diffubrain.utils import resolve_device


def main(args):
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    cfg = Config(**{k: v for k, v in checkpoint["config"].items() if k in Config.__dataclass_fields__})
    device = resolve_device(args.device)
    model = DiffuBrain(cfg.feature_channels, cfg.num_classes, cfg.diffusion_steps, cfg.edge_gamma, cfg.conditioning_dropout).to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()
    logits, labels = [], []
    for record in read_manifest(args.manifest):
        if record.get("split") != "val" or record.get("label") is None:
            continue
        is_2d = record.get("dataset", "").lower().startswith("brisc")
        sample = ManifestDataset([record], is_volume=not is_2d)[0]
        with torch.no_grad():
            output = model(sample["image"].unsqueeze(0).to(device), "brisc" if is_2d else "brats", return_loss=False)
        logits.append(output["cls_logits"].cpu().numpy()[0])
        labels.append(int(sample["label"]))
    scaler = TemperatureScaler().fit(np.array(logits), np.array(labels))
    probabilities = scaler.transform(np.array(logits))
    result = {"temperature": scaler.temperature, "ece": expected_calibration_error(probabilities, np.array(labels))}
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cpu")
    main(parser.parse_args())
