from __future__ import annotations

import argparse
import json

import numpy as np
import torch

from diffubrain.config import Config
from diffubrain.data import ManifestDataset, read_manifest
from diffubrain.models import DiffuBrain
from diffubrain.training.metrics import multiclass_metrics, segmentation_metrics
from diffubrain.utils import resolve_device


def evaluate(args):
    checkpoint = torch.load(args.checkpoint, map_location="cpu")
    cfg = Config(**{k: v for k, v in checkpoint["config"].items() if k in Config.__dataclass_fields__})
    device = resolve_device(args.device)
    model = DiffuBrain(cfg.feature_channels, cfg.num_classes, cfg.diffusion_steps, cfg.edge_gamma, cfg.conditioning_dropout).to(device)
    model.load_state_dict(checkpoint["model"])
    model.eval()
    records = [r for r in read_manifest(args.manifest) if r.get("split") == args.split]
    result = {"segmentation": [], "classification": []}
    with torch.no_grad():
        for record in records:
            is_2d = record.get("dataset", "").lower().startswith("brisc")
            dataset = ManifestDataset([record], is_volume=not is_2d)
            sample = dataset[0]
            image = sample["image"].unsqueeze(0).to(device)
            output = model(image, "brisc" if is_2d else "brats", return_loss=False)
            if sample["mask"] is not None:
                probability = output["seg_logits"].sigmoid().cpu().numpy()
                result["segmentation"].append(segmentation_metrics(probability, sample["mask"].unsqueeze(0).numpy()))
            if sample["label"] is not None:
                prediction = output["cls_logits"].argmax(1).cpu().numpy()
                result["classification"].append({"prediction": int(prediction[0]), "target": int(sample["label"])})
    if result["classification"]:
        result["classification_summary"] = multiclass_metrics(np.array([x["prediction"] for x in result["classification"]]), np.array([x["target"] for x in result["classification"]]))
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(result, handle, indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument("--output", required=True)
    parser.add_argument("--device", default="cpu")
    evaluate(parser.parse_args())
