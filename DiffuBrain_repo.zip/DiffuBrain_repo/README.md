# DiffuBrain

Research code for mixed-dimensional brain MRI segmentation and classification with dataset-specific encoders, a shared 128-channel feature space, edge-weighted conditional diffusion refinement, partial-label supervision, calibration, and explanation analysis.

## Repository layout

```text
diffubrain/
  data/          Manifest-based datasets and preprocessing
  models/        Encoders, diffusion refinement, and task heads
  training/      Losses, metrics, calibration, and explanations
configs/         Reproducible experiment configuration
scripts/         Command-line entry points
tests/           Lightweight model and data smoke tests
artifacts/       Split indices, checkpoints, predictions, metrics, calibration
```

## Installation

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
```

## Data manifests

The loaders use JSONL manifests. Each line describes one sample:

```json
{"id":"case-001","dataset":"brisc","image":"/data/case-001.npy","mask":"/data/case-001-mask.npy","label":2,"split":"train"}
```

Images may be `.npy` arrays or NIfTI files when `nibabel` is installed. The expected shapes are `H x W` for BRISC and `D x H x W` or `C x D x H x W` for volumetric data. Missing `mask` or `label` fields are supported.

## Training

```bash
python scripts/train.py --config configs/default.yaml --manifest /data/manifest.jsonl --output runs/diffubrain
```

Training uses paired mini-batches: one 2D batch and one 3D batch. Checkpoints, configuration, seed metadata, and validation summaries are written under the output directory.

## Evaluation and calibration

```bash
python scripts/evaluate.py --checkpoint runs/diffubrain/seed-42/best.pt --manifest /data/manifest.jsonl --split test --output runs/eval.json
python scripts/calibrate.py --checkpoint runs/diffubrain/seed-42/best.pt --manifest /data/manifest.jsonl --output runs/calibration.json
python scripts/explain.py --checkpoint runs/diffubrain/seed-42/best.pt --manifest /data/manifest.jsonl --output runs/explanations
```

Use `--device cpu` for a CPU smoke test. The default configuration is deliberately explicit: input shapes, loss weights, diffusion schedule, sampling steps, seeds, and split names are all recorded in the run directory.

## Reproducibility

Run the five configured seeds with:

```bash
python scripts/run_seeds.py --config configs/default.yaml --manifest /data/manifest.jsonl --output runs/five-seeds
```

The repository does not include private data, trained weights, or external benchmark files. Supply data through a manifest and follow each dataset's access conditions.

For the publication release, place the fixed split indices for every dataset and task under `artifacts/splits/`, the five seed checkpoints under `artifacts/checkpoints/`, and per-case test predictions and metrics under `artifacts/predictions/` and `artifacts/metrics/`. Calibration parameters and reports belong under `artifacts/calibration/`.

## Citation

Use the manuscript files in the repository for the paper citation and report the exact configuration and seed outputs associated with a result.
