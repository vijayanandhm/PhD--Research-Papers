# Data preparation

Keep data outside the repository and create a JSONL manifest with one record per image or volume. Required fields are `id`, `dataset`, `image`, and `split`. Add `mask` and `label` only when the corresponding annotation is available.

Dataset names beginning with `brisc` use the 2D encoder. Names beginning with `brats` use the 3D encoder. The loader accepts NumPy arrays and, with the optional medical dependency installed, NIfTI files.

Example:

```json
{"id":"brisc-0001","dataset":"brisc","image":"/data/brisc/0001.npy","mask":"/data/brisc/0001-mask.npy","label":0,"split":"train"}
{"id":"peds-0001","dataset":"brats-peds","image":"/data/peds/0001.npy","mask":"/data/peds/0001-mask.npy","split":"test"}
```
